﻿Imports System.IO
Imports System.Net
Imports System.Text

Public Class RTV_Plugin
    Public NOMBRE As String = "RTV SDK TEST" 'Nombre del Plugin
    Public ASYNC = False 'Evita la salida del Plugin cuando termina de ejecutarse ACCION
    Public ESTADO As String = "" 'Texto mostrado en la barra de estado mientras se realiza ASYNC

    Dim WithEvents Descargador_HTML As New WebClient() 'Descargador de datos
    Dim UserAgent_1 As String = "Mozilla/5.0 (Android; Mobile; rv:30.0) Gecko/30.0 Firefox/30.0" 'Android (Mobile)
    Dim UserAgent_2 As String = "Dalvik/1.6.0 (Linux; U; Android 4.4.2; TegraNote-P1640 Build/KOT49H)" 'Android (Tablet)
    Dim UserAgent_3 As String = "Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0" 'Windows (Escritorio)

    Public Function ACCION(ByVal Argumento As String)
        On Error Resume Next
        'Ejemplo de argumento de accion: RTV_PLUGIN_RTV_SDK://MODO://URL
        Dim MODO_Solicitado = Argumento.Remove(Argumento.IndexOf("://")) 'Obtiene el MODO especificado
        Dim URL_SOLICITADO = Argumento.Remove(0, Argumento.IndexOf("://") + 3) 'Obtiene el URL solicitado
        Dim Codigo_Lista_M3U_Final As String = "#EXTM3U" & vbNewLine

        Dim PLUGIN_ACCESS_NAME As String = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name
        'El nombre de acceso al Plugin se establece en las propiedades del proyecto con 'Nombre del ensamblado' y 'Espacio de nombres de la raiz'
        'Debe empezar con "RTV_PLUGIN_" (sin comillas) y no puede contener caracteres especiales ni espacios (excepto guion bajo)

        If MODO_Solicitado = "INICIO" Then
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar MsgBox" & vbNewLine & "RTV_MSGBOX://Mensaje de ejemplo" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar OpenBrowserLink" & vbNewLine & "RTV_OPEN_BROWSER_LINK://http://rosadintv.github.io" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar MultiSelect" & vbNewLine & "RTV_MULTISELECT://[SELECT=ALL][TITLE=Ejemplo][URL=RTV_MSGBOX://Seleccionaste: RTV_MULTISELECT_RESULT][NAME=ITEM1][NAME=ITEM2][NAME=ITEM3]" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar MultiURL" & vbNewLine & "RTV_MULTIURL://[URL Item 1://RTV_MSGBOX://Seleccionaste el Item 1[/URL][URL Item 2://RTV_MSGBOX://Seleccionaste el Item 2[/URL]" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar InputBox" & vbNewLine & "RTV_MSGBOX://Hola [INPUTBOX ¿Como te llamas?[/INPUTBOX] :)" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Menu contextual" & vbNewLine & "RTV_MSGBOX://Dame clic derecho para ver el menu contextual[CONTEXTUAL Item 1://RTV_MSGBOX://Seleccionaste el Item 1[/CONTEXTUAL][CONTEXTUAL Item 2://RTV_MSGBOX://Seleccionaste el Item 2[/CONTEXTUAL]" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar ASYNC" & vbNewLine & PLUGIN_ACCESS_NAME & "://INICIAR_ASYNC://SAFE" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar GET" & vbNewLine & PLUGIN_ACCESS_NAME & "://INICIAR_GET://SAFE" & vbNewLine
            Codigo_Lista_M3U_Final += "#EXTINF:-1 tvg-logo=" & Chr(34) & "RTV_INTERNAL_LOGO://PictureBox12" & Chr(34) & "," & "Iniciar POST" & vbNewLine & PLUGIN_ACCESS_NAME & "://INICIAR_POST://SAFE" & vbNewLine
        End If

        If MODO_Solicitado = "INICIAR_ASYNC" Then
            ASYNC = True
            For i As Integer = 0 To 10
                ESTADO = "Estado numero " & i
                Threading.Thread.Sleep(1000)
            Next
            ASYNC = False
            Return "RTV_MSGBOX://ASYNC terminado :)"
        End If

        If MODO_Solicitado = "INICIAR_GET" Then
            Dim resultado As String = GetPageHTMLCustom("http://google.com.ar/RosadinTV", UserAgent_3, "http://google.com.ar")
            resultado = resultado.Remove(0, resultado.LastIndexOf("<p>") + 3)
            resultado = resultado.Replace("<ins>", "")
            resultado = resultado.Replace("</ins>", "")
            resultado = resultado.Replace("<code>", Chr(34))
            resultado = resultado.Replace("</code>", Chr(34))
            Return "RTV_MSGBOX://Resultado:[newline]" & resultado
        End If

        If MODO_Solicitado = "INICIAR_POST" Then
            Dim resultado As String = GetPageHTMLCustom_POST("RosadinTV", "http://google.com.ar/", UserAgent_3, "http://google.com.ar")
            resultado = resultado.Remove(0, resultado.LastIndexOf("<p>") + 3)
            resultado = resultado.Replace("<ins>", "")
            resultado = resultado.Replace("</ins>", "")
            resultado = resultado.Replace("<code>", Chr(34))
            resultado = resultado.Replace("</code>", Chr(34))
            Return "RTV_MSGBOX://Resultado:[newline]" & resultado
        End If

        Return Codigo_Lista_M3U_Final
    End Function

    Public Function GetPageHTMLCustom(ByVal URL As String, ByVal UserAgent_Custom As String, ByVal Referer_Custom As String) As String
        Dim RESULTADO As String = ""
        Descargador_HTML.Encoding = Encoding.UTF8
        Descargador_HTML.Headers.Clear()
        Descargador_HTML.Headers(Net.HttpRequestHeader.Referer) = Referer_Custom
        Descargador_HTML.Headers(Net.HttpRequestHeader.UserAgent) = UserAgent_Custom
        Try
            RESULTADO = Descargador_HTML.DownloadString(URL) 'Intentar obtener resultado de manera directa
        Catch falla As WebException 'Intentar obtener resultado ignorando errores
            Using sr = New StreamReader(falla.Response.GetResponseStream())
                RESULTADO = sr.ReadToEnd()
            End Using
        End Try
        Return RESULTADO
    End Function

    Public Function GetPageHTMLCustom_POST(ByVal POST As String, ByVal URL As String, ByVal UserAgent_Custom As String, ByVal Referer_Custom As String) As String
        Dim RESULTADO As String = ""
        Descargador_HTML.Encoding = Encoding.UTF8
        Descargador_HTML.Headers.Clear()
        Descargador_HTML.Headers(Net.HttpRequestHeader.Referer) = Referer_Custom
        Descargador_HTML.Headers(Net.HttpRequestHeader.UserAgent) = UserAgent_Custom
        Try
            RESULTADO = Descargador_HTML.UploadString(URL, POST) 'Intentar obtener resultado de manera directa
        Catch falla As WebException 'Intentar obtener resultado ignorando errores
            Using sr = New StreamReader(falla.Response.GetResponseStream())
                RESULTADO = sr.ReadToEnd()
            End Using
        End Try
        Return RESULTADO
    End Function
End Class
