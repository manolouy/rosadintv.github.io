﻿Imports System.ComponentModel
Imports System.Text

Public Class DEBUG
    Dim DEBUG_MODE As String = ""
    Dim WithEvents DEBUG_BW As New ExtendedBackgroundWorker

    Private Sub InputBox_General_Custom_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        valor.TabIndex = 0
        valor.Focus()

        'Si existe DEBUG_MODE.txt se abre el modo DEBUG
        If IO.File.Exists("DEBUG_MODE.txt") Then
            DEBUG_MODE = IO.File.ReadAllText("DEBUG_MODE.txt", Encoding.UTF8)
        Else
            MsgBox("Esta aplicacion se debe ejecutar mediante RosadinTV", MsgBoxStyle.Critical, "Error")
            Me.Close()
        End If
        '

        'Establecer valores iniciales
        Me.Text = "RTV SDK DEBUG"
        contenido.Text = "¿Que accion quieres ejecutar?"
        valor.Text = "" 'Ejemplo: INICIO://SAFE
        valor.TabIndex = 0
        valor.Focus()
        valor.SelectionStart = valor.Text.Length
        valor.SelectionLength = 0
        '

        'Seleccion DEBUG_MODE
        Dim DEBUG_HANDLED As Boolean = False
        If DEBUG_MODE = "SILENT" Then
            DEBUG_HANDLED = True
        End If
        If DEBUG_MODE = "CLIPBOARD" Then
            DEBUG_HANDLED = True
        End If
        If DEBUG_MODE = "FILE" Then
            DEBUG_HANDLED = True
        End If
        If DEBUG_HANDLED = False Then
            DEBUG_MODE = "NORMAL"
        End If
        Me.Text += " [" & DEBUG_MODE & "]" 'Mostrar el DEBUG_MODE actual en el titulo 
        '

    End Sub

    Private Sub aceptar_Click(sender As Object, e As EventArgs) Handles aceptar.Click
        If aceptar.Text = "Aceptar" Then
            valor.Enabled = False
            aceptar.Text = "Cancelar"
            DEBUG_BW.RunWorkerAsync()
        Else
            If DEBUG_BW.IsBusy Then
                DEBUG_BW.CancelImmediately()
                valor.Enabled = True
                aceptar.Text = "Aceptar"
            Else
                valor.Enabled = True
                aceptar.Text = "Aceptar"
            End If
        End If

    End Sub

    Private Sub valor_KeyPress(sender As Object, e As KeyPressEventArgs) Handles valor.KeyPress
        If e.KeyChar = Convert.ToChar(Keys.Enter) Then
            e.Handled = True
            aceptar_Click(Nothing, Nothing)
        End If
    End Sub

    Private Sub DEBUG_BW_DoWork(sender As Object, e As DoWorkEventArgs) Handles DEBUG_BW.DoWork
        Dim resultado As String = ""
        If valor.Text.Contains("://") Then
            Dim RTV_Plugin As New RTV_Plugin
            resultado = RTV_Plugin.ACCION(valor.Text)
        End If

        If DEBUG_MODE = "SILENT" = False Then
            Me.Invoke(DirectCast(Sub()
                                     If String.IsNullOrEmpty(resultado) Then
                                         MsgBox("La accion no devolvio resultados :(", MsgBoxStyle.Critical, "Error")
                                     Else

                                         If DEBUG_MODE = "NORMAL" Then
                                             MsgBox(resultado, Nothing, "Resultado")
                                         End If
                                         If DEBUG_MODE = "CLIPBOARD" Then
                                             Clipboard.SetText(resultado)
                                             MsgBox("Resultado copiado al portapapeles", MsgBoxStyle.Information, "Aviso")
                                         End If
                                         If DEBUG_MODE = "FILE" Then
                                             SaveFileDialog1.Title = "¿Donde lo quieres guardar?"
                                             SaveFileDialog1.FileName = "Resultado"
                                             SaveFileDialog1.Filter = "Archivo de texto | *.txt*"
                                             Dim res As DialogResult = SaveFileDialog1.ShowDialog(Me)
                                             If res = DialogResult.OK Then
                                                 IO.File.WriteAllText(SaveFileDialog1.FileName, resultado, Encoding.UTF8)
                                             End If
                                         End If

                                     End If
                                 End Sub, MethodInvoker))
        End If

    End Sub

    Private Sub DEBUG_BW_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles DEBUG_BW.RunWorkerCompleted
        valor.Enabled = True
        aceptar.Text = "Aceptar"
    End Sub

    Private Sub InputBox_General_Custom_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Application.Exit()
        Application.ExitThread()
    End Sub

End Class
